package com.bean;

import java.util.ArrayList;

import com.dao.QuestionDao;

public class Question {
	private String qid;
	private String institute;
	private String question;
	private String doq;
	private String module;
	private String subject;
	private String semester;
	private String branch;

	public Question() {
	}

	public int addQuestion() {
		QuestionDao qd = new QuestionDao();
		int i = qd.saveQuestion(this);
		return i;

	}

	public ArrayList<String> showQuestion(String branch, String semester, String subject) {
		ArrayList<String> getdata = new ArrayList<String>();
		QuestionDao qd = new QuestionDao();
		getdata = qd.selectQuestions(this);
		return getdata;
	}

	public String getQid() {
		return qid;
	}

	public void setQid(String qid) {
		this.qid = qid;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getDoq() {
		return doq;
	}

	public void setDoq(String doq) {
		this.doq = doq;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSemester() {
		return semester;
	}

	public void setSemester(String semester) {
		this.semester = semester;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

}
