package com.bean;

import com.dao.AddMemberDao;

public class Member {
	private int id;
	private String name;
	private String email;
	private String userName;
	private String password;
	private String contactNumber;

	public int add_Member() {
		AddMemberDao p = new AddMemberDao();
		int i = p.saveMember(this);
		System.out.println(this);
		return i;
	}

	public boolean login() {
		AddMemberDao p = new AddMemberDao();
		boolean b = p.loginValidate(this);
		return b;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

}
