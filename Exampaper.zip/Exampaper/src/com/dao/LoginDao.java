package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.LoginBean;
import com.connection.ConnectionProvider;
public class LoginDao {

	public static boolean validate(LoginBean bean){
		boolean status=false;
		try{
			Connection con=ConnectionProvider.getCon();
			
			System.out.println("connection :"+con);
			PreparedStatement ps=con.prepareStatement("select * from user where user_name=? and password=?");
			ps.setString(1,bean.getUserName());
			System.out.println(bean.getUserName());
			ps.setString(2, bean.getPass());
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			System.out.println(status);
		}catch(Exception e){
			System.out.println(e);
		}
		return status;
		
	}
}
