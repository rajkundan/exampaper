package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.bean.Question;
import com.connection.ConnectionProvider;

public class QuestionDao {
	ArrayList<String> getdata = new ArrayList<String>();

	public int saveQuestion(Question question) {
		try {
			Connection con = ConnectionProvider.getCon();
			System.out.println("Connection " + con);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select qid from questions");
			String temp = "1000";
			while (rs.next()) {
				temp = rs.getString(1);
				if ((rs.getString("qid")).equals(question.getQid())) {
					System.out.println("qustions already exist");
					return 1;
				}
			}
			temp = String.valueOf(Integer.parseInt(temp) + 1);
			PreparedStatement pstmt = con.prepareStatement(
					"insert into questions(qid,institute,question,doq,module,subject,semester,branch) values(?,?,?,?,?,?,?,?)");
			pstmt.setString(1, temp);
			pstmt.setString(2, question.getInstitute());
			pstmt.setString(3, question.getQuestion());
			pstmt.setString(4, question.getDoq());
			pstmt.setString(5, question.getModule());
			pstmt.setString(6, question.getSubject());
			pstmt.setString(7, question.getSemester());
			pstmt.setString(8, question.getBranch());
			pstmt.executeUpdate();
			return 2;
		} catch (Exception e) {
			System.out.println(e);
		}

		return 0;
	}

	public ArrayList<String> selectQuestions(Question question) {
		try {

			Connection con = ConnectionProvider.getCon();
			System.out.println("Connection " + con);
			
			
			/*PreparedStatement pstmt = con
					.prepareStatement("SELECT * from questions WHERE branch='?' and semester='?' AND subject='?'");
			pstmt.setString(1, question.getBranch());
			pstmt.setString(2, question.getSemester());
			pstmt.setString(3, question.getSubject());
			ResultSet rs = pstmt.executeQuery();*/
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM questions WHERE branch='"+question.getBranch()+"' and semester='"+question.getSemester()+"' and subject='"+question.getSubject()+"'");
			
			
			//SELECT * FROM questions WHERE branch='"+question.getBranch()+"' and semester='"+question.getSemester()+"' and subject='"+question.getSubject()+"' 
			
			
			while (rs.next()) {
				//System.out.println(rs.getString("qid"));
				getdata.add(rs.getString("qid"));
				getdata.add(rs.getString("institute"));
				getdata.add(rs.getString("question"));
				getdata.add(rs.getString("doq"));
				getdata.add(rs.getString("module"));
				getdata.add(rs.getString("subject"));
				getdata.add(rs.getString("semester"));
				getdata.add(rs.getString("branch"));
				System.out.println(getdata);
				return getdata;
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}

}
