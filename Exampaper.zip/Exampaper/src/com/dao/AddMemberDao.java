package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.bean.Member;
import com.connection.ConnectionProvider;

public class AddMemberDao {

	
public boolean loginValidate(Member member) {
		
		boolean status=false;
		try{
			Connection con=ConnectionProvider.getCon();
			
			System.out.println("connection :"+con);
			System.out.println("prads"+member.getUserName());
			PreparedStatement ps=con.prepareStatement("select * from members where user_name=? and password=?");
			ps.setString(1,member.getUserName());
			ps.setString(2,member.getPassword());
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			System.out.println(status);
		}catch(Exception e){
			System.out.println(e);
		}
		return status;
	}
	public int saveMember(Member member) {
		try {
			Connection con = ConnectionProvider.getCon();
			System.out.println("Connection " + con);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select id,email from members");
			String temp = "101";
			while (rs.next()) {
				temp = rs.getString(1);
				if ((rs.getString("email")).equals(member.getEmail())) {
					System.out.println("Email already exist");
					return 1;
				}
			}
			temp = String.valueOf(Integer.parseInt(temp) + 1);
			PreparedStatement pstmt = con.prepareStatement("insert into members(id,name,email,user_name,password,contact_number) values(?,?,?,?,?,?)");
			pstmt.setString(1, temp);
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getEmail());
			pstmt.setString(4, member.getUserName());
			pstmt.setString(5, member.getPassword());
			pstmt.setString(6, member.getContactNumber());
			pstmt.executeUpdate();
			return 2;
		} catch (Exception e) {
			System.out.println(e);
		}

		return 0;
	}

}
