package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider implements Provider {
	static Connection con = null;

	static {
		try {
			Class.forName(DRIVER);
			con = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);
			//System.out.println(DRIVER);
		} catch (Exception e) {
		}
	}

	public static Connection getCon() {
		//System.out.println(con);
		return con;
	}
}
